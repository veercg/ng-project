! function() {
  'use strict';

  angular.module('projectApp').filter('characters', function() {
    return function(input, chars, breakOnWord) {
      if (isNaN(chars)) {
		  return input;
	  }
      if (chars <= 0) {
		  return '';
	  }
      if (input && input.length >= chars) {
        input = input.substring(0, chars);

        if (!breakOnWord) {
          var lastspace = input.lastIndexOf(' ');
          //get last space
          if (lastspace !== -1) {
            input = input.substr(0, lastspace);
          }
        } else {
          while (input.charAt(input.length - 1) == ' ') {
            input = input.substr(0, input.length - 1);
          }
        }
        return input + '...';
      }
      return input;
    };
  });
  angular.module('projectApp').filter('words', function() {
    return function(input, words) {
      if (isNaN(words)) {
		  return input;
	  }
      if (words <= 0) {
		  return '';
	  }
      if (input) {
        var inputWords = input.split(/\s+/);
        if (inputWords.length > words) {
          input = inputWords.slice(0, words).join(' ') + '...';
        }
      }
      return input;
    };
  });

  angular.module('projectApp').filter('iif', function() { //immediate if filter
    return function(input, trueValue, falseValue) { //condition | iff: [value for true](optional) : [value for false](optional)
      var trueValue = trueValue ? trueValue : true;
      var falseValue = falseValue ? falseValue : false;

      return input ? falseValue : trueValue;
    };
  });
  angular.module('projectApp').filter('unsafe', function($sce) {
    return function(val) {
      return $sce.trustAsHtml(val);
    };
  });

  angular.module('projectApp').filter('monthName', [function() {
    return function(monthNumber) {
      var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
      return monthNames[monthNumber - 1];
    };
  }]);

  angular.module('projectApp').filter('trustAsHTML', ['$sce', function($sce) {
    return function(text) {
      return $sce.trustAsHtml(text);
    };
  }]);


  //Medicare Card formatter for the review page
  angular.module('projectApp').filter('medicareNumber', function() {
    var filter = function(text) {
      if (text) {
        var temp = text.substr(0, 4) + ' ' + text.substr(4, 5) + ' ' + text.substr(9, 1);
        return temp;
      }
    };
    return filter;
  });
  angular.module('projectApp').filter('medicareMiddleInitial', function() {
    var filter = function(text) {
      if (text != "") {
        return text.toUpperCase();
      } else {
        return "none";
      }
    };
    return filter;
  });
  angular.module('projectApp').filter('addMonths', function() {
    var filter = function(text) {
      if (text > 1) {
        return text + " months";
      } else {
        return text + " month";
      }
    };
    return filter;
  });
  angular.module('projectApp').filter('range', function() {
    var filter = function(arr, lower, upper) {
      for (var i = lower; i <= upper; i++) {
        arr.push(i);
      }
      return arr;
    };
    return filter;
  });

  angular.module('projectApp').filter('rangeReversed', function() {
    var filter = function(arr, upper, lower) {
      for (var i = upper; i > lower; i--) {
        arr.push(i);
      }
      return arr;
    };
    return filter;
  });
  angular.module('projectApp').filter('toArray', function() {
    return function(obj) {
      var result = [];
      for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
          var temp = {};
          temp.code = key;
          temp.value = obj[key];
          result.push(temp);
        }
      }
      return result;
    };
  });
  angular.module('projectApp').filter('toUpperCaseFirstLetter', function() {
    var filter = function(str) {
      if(str){
        return str[0].toUpperCase() + str.substr(1);
      }
      else{
        return '';
      }
    };
    return filter;
  });

}();
