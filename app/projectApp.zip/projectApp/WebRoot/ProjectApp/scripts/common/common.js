/*
 * eneableDisable: Add / remove an attributed based on position in the form
 *
 *
 * Purpose: stops the user clicking past the first or last step in the form
 *
 *  byRefEnabledElement var: the element id of the element to enable
 *
 *  byRefDisabedElement var: the element id of the element to disable
 *
 * */

$(document).keydown(
    function (e) {
        //alert(e.keyCode);
        if (e.keyCode == 39) {
            $(".move:focus").next().focus();

        }

        if (e.keyCode == 37) {

            $(".move:focus").prev().focus();

        }
        if (e.keyCode == 9) {
            $(".checkbox-inline").focusin(function () {
                //alert('test');
                $(this).css("border", "1px dotted #621a4b");
            });
            $(".checkbox-inline").focusout(function () {
                $(this).css("border-color", "#ffffff");
            });
        }
    }
);

var isEmptyObject = function (obj) {
    if (obj) {
        return obj.length === 0;
    }
    return true;
};

function setCookie(name, value, expires, path, domain) {
    var cookie = name + "=" + value + ";";
    if (expires) {
        // If it's a date
        if (expires instanceof Date) {
            // If it isn't a valid date
            if (isNaN(expires.getTime()))
                expires = new Date();
        } else
            expires = new Date(new Date().getTime() + parseInt(expires,10) * 1000 * 60 * 60 * 24);
        cookie += "expires=" + expires.toGMTString() + ";";
    }

    if (path)
        cookie += "path=" + path + ";";
    if (domain)
        cookie += "domain=" + domain + ";";

    cookie += "secure;";
    document.cookie = cookie;
}

function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(";");
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
			c = c.substring(1, c.length);
		}
        if (c.indexOf(nameEQ) == 0) {
			return c.substring(nameEQ.length, c.length);
		}
    }
    return null;
}

function eraseCookie(name) {
    setCookie(name, "", -1);
}

function getUniqueId() {
    var d = new Date();
    var i = d.getTime();
    var unitId = i.toString();
    var randomNumber = Math.floor(Math.random() * 1000000);
    unitId = unitId.toString() + randomNumber.toString();
    return unitId;
}

function getCurrentTime() {
    var dat = new Date();
    var tim = dat.getTime();
    var curValue = tim.toString();
    curValue = curValue.toString();
    return curValue;
}
