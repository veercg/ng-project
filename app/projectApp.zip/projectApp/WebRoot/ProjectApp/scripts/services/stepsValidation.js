// define module for app
var appValidation = angular.module("projectApp.formValidation", []);

appValidation.factory('factories.validator', function () {
    return {
        regex: {
            bsb: /^((73\d{4})|(03\d{4}))$/,
            savingsbsb: /^((73)\d{4})$/,
            chequebsb: /^((03)\d{4})$/,
            name: /^[a-z-' ]{2,}$/i,
            digits: /^[1-9]{1}[\d]*$/,
            digitsZero: /^([0]{1})$|^([1-9]{1}[\d]*)$/,
            postcodedigits: /^[\d]{4}$/,
            digitsOnly: /^[\d]*$/,
            year: /^(19|20)\d{2}$/,
            phone: /^(0?[45][0-9]{8})$/,
            depositAmount: /^[1-9]\d*(?:\.\d{0,2})?$/,
            tenureLength: /^[0-9]+$/,
            addressline: /^[A-Za-z0-9\s\-\&\'\(\)\/\:\;\,]+$/,
            city: /^[a-zA-Z\s\-\.\\s\/\'\d\s]+$/,
            postcode: {
                ACT: /^(260[0-9]|261([0-2]|[4-8])|290[0-6]|291[1-4]|2540|2620|0200|0221)$/,
                NSW: /^(100[1-9]|10[1-3][0-9]|104[0-6]|11[0-9]{2}|12[0-3][0-9]|1240|129[1-9]|13[0-5][0-9]|1360|139[1-9]|1[4-9][0-9]{2}|2[0-4][0-9]{2}|25[0-8][0-9]|259[0-4]|261[1-9]|26[2-9][0-9]|2[7-8][0-9]{2}|3500|35[8][5-6]|3644|3707)$/,
                NT: /^(08[0-9]{2}|090[0-9])$/,
                QLD: /^(4[0-7][0-9]{2}|48[0-8][0-9]|489[0-5]|90[0-1][0-9]|902[0-3]|9464|972([6]|[8-9]))$/,
                SA: /^(5[0-8][0-9]{2}|59[0-4][0-9]|5950|872)$/,
                TAS: /^(7[0-3][0-9]{2}|74[0-6][0-9]|7470|78[0-9]{2}|79[0-1][0-9]|792[0-3])$/,
                VIC: /^(3[0-8][0-9]{2}|39[0-8][0-9]|399[0-6]|800[1-9]|80[1-9][0-9]|8[1-7][0-9]{2}|88[0-6][0-9]|887[0-3])$/,
                WA: /^(6[0-8][0-9]{2}|69[0-8][0-9]|699[0-7]|872)$/
            },
            email: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/

        }
    };
});
appValidation.directive('regex', ['factories.validator',
    function (validationFactory) {
        return {
            require: 'ngModel',
            /* priority: 10,*/
            link: function (scope, elm, attrs, ctrl) {

                var validator = function (val) {
                    var evaled = scope.$eval(attrs.regex);

                    if (evaled) {
                        for (var i = 0; i < evaled.length; i++) {
                            var test = !val || validationFactory.regex[evaled[i]].test(val);
                            ctrl.$setValidity('regex' + i, test);

                        }
                    } else {
                        var test = !val || validationFactory.regex[attrs.regex].test(val);
                        ctrl.$setValidity('regex', test);
                    }
                    return test ? val : undefined;
                };
                ctrl.$parsers.push(validator);

            }
        };
    }
]);
appValidation.directive('minvalue', [

    function () {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {

                var validator = function (val) {
                    var evaled = scope.$eval(attrs.minvalue);
                    var test = true;

                    if (evaled || evaled == 0) {
                        evaled = parseInt(evaled, 10);

                        test = !val || val >= evaled;
                        ctrl.$setValidity('minvalue', test);
                    }
                    return test ? val : undefined;
                };
                ctrl.$parsers.push(validator);
            }
        };
    }
]);

appValidation.directive('maxvalue', [

    function () {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {

                var validator = function (val) {
                    var evaled = scope.$eval(attrs.maxvalue);
                    var test = true;

                    if (evaled || evaled == 0) {
                        evaled = parseInt(evaled, 10);

                        test = !val || val <= evaled;
                        ctrl.$setValidity('maxvalue', test);
                    }
                    return test ? val : undefined;
                };
                ctrl.$parsers.push(validator);
            }
        };
    }
]);

appValidation.directive('equals', [
    '$parse',
    function ($parse) {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {

                var equalTo = $parse(attrs.equals)(scope);

                var validator = function (val) {
                    var test = !equalTo || !val || equalTo === val;
                    ctrl.$setValidity('equals', test);
                    return test ? val : undefined;
                };
                ctrl.$parsers.push(validator);
                scope.$watch(attrs.equals, function () {
                    equalTo = $parse(attrs.equals)(scope);
                    validator(ctrl.$viewValue);
                });
            }
        };
    }
]);





appValidation.directive('postcode', [
    '$parse',
    'factories.validator',
    function ($parse, validationFactory) {
        return {
            require: 'ngModel',
            link: function (scope, elm, attrs, ctrl) {
                var check = function (selectedstate, value) {
                    if (selectedstate && value) {
                        return validationFactory.regex.postcode[selectedstate]
                            .test(value);
                    } else if (!selectedstate && value) {
                        return validationFactory.regex.postcodedigits.test(value);
                    }
                    return true;
                };

                var validator = function (val) {
                    var selectedState = $parse(attrs.postcode)(scope);
                    var postcodeValue = val;
                    var test = check(selectedState, postcodeValue);
                    ctrl.$setValidity('postcode', test);
                    return test ? val : val;
                };
                ctrl.$parsers.push(validator);
                scope.$watch(attrs.postcode, function () {
                    validator(ctrl.$viewValue);
                });
            }
        };
    }
]);




appValidation.directive('ngBlur', ['$parse',
    function ($parse) {
        return function (scope, element, attr) {
            var fn = $parse(attr['ngBlur']);
            element.bind('blur', function (event) {
                scope.$apply(function () {
                    fn(scope, {
                        $event: event
                    });
                });
            });
        }
    }
]);
