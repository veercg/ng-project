angular.module('projectApp')
    .service('RESTHelper', ["Configuration", "$cookies", "genericFactory",
        function(Configuration, $cookies, genericFactory) {

            // To check if the environment is local or not
            var isLocal = genericFactory.isLocal();

            var context = (window.location.origin) ? window.location.origin : genericFactory.getOrigin(window.location);
            var serviceContext = '/oregon/oao/pol/services';
            var baseURL = context + serviceContext;

            if (isLocal) {
                var refDataServiceURL = './res/refData.json';
                

            } else {
                var refDataServiceURL = baseURL + '/getRefData';

            }

            // Added for Term Deposits

            this.getRefDataURL = function() {
                return refDataServiceURL;
            };


            var xsrfToken = '';
            xsrfToken = $cookies.get('TD_XSRF_TOKEN');
            /*angular.forEach($cookies, function (v, k) {
                if (k.indexOf('TD_XSRF_TOKEN') > -1) {
                    xsrfToken = v;
                }
            });*/

            this.getHeaders = function() {
                return {
                    'Content-Type': 'application/json',
                    'X-XSRF-Token': xsrfToken
                };
            };

            this.getSiteType = function() {
                var siteType = Configuration.appMode();
                console.log("iPAD Flag", Configuration.iPad);
                if (Configuration.iPad) {
                    siteType = "nativetablet";
                } else if (Configuration.isNative) {
                    siteType = "nativemobile";
                } else if (Configuration.isTablet) {
                    siteType = "tablet";
                }
                return siteType;
            };
        }
    ]);

angular.module('projectApp').service('RESTAPIService', [
    '$http', '$state', '$q', "Configuration", 'RESTHelper', '$location', "genericFactory", "$rootScope",
    function($http, $state, $q, Configuration, RESTHelper, $location, genericFactory, $rootScope) {

        // To check if the environment is local or not
        var isLocal = genericFactory.isLocal();

        var methodType = "POST";

        if (isLocal) {
            methodType = "GET";
        }

        return {

            //Start of all Service calls for Term deposits

            //Service call to get all the environment properties
            getEnvironmentProperties: function() {
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: RESTHelper.getRefDataURL(),
                    headers: RESTHelper.getHeaders()
                }).success(function(data, status) {
                    if (!isEmptyObject(data)) {
                        deferred.resolve(data, status);
                    } else {
                        deferred.reject(status);
                        $state.go('error');
                    }
                }).error(function(data, status) {
                    deferred.reject(status);
                    $state.go('error');
                });
                return deferred.promise;
            }

            //End of all Service calls for Term deposits

        };

    }
]);
