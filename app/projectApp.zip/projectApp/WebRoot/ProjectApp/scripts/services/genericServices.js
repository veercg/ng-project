angular.module('projectApp.services')
.service('loggerService', ['$log', '$filter',
   function ($log, $filter) {
        // this.debuggingEnabled = isDebuggingEnabled();
        this.debuggingEnabled = true;
        this.format = 'dd-MMM-yyyy h:mm:ss a';

        this.log = function () {
            if (this.debuggingEnabled) {
                for (var i = 1; i < arguments.length; i++) {
                    $log.log("[" + $filter('date')(new Date(), this.format) + "] -- " + arguments[0] + " -- " + JSON.stringify(arguments[i]));
                }
            }
        }

        this.debug = function () {
            if (this.debuggingEnabled) {
                for (var i = 1; i < arguments.length; i++) {
                    $log.debug("[" + $filter('date')(new Date(), this.format) + "] -- " + arguments[0] + " -- " + JSON.stringify(arguments[i]));
                }
            }
        }

        this.info = function () {
            if (this.debuggingEnabled) {
                for (var i = 1; i < arguments.length; i++) {
                    $log.info("[" + $filter('date')(new Date(), this.format) + "] -- " + arguments[0] + " -- " + JSON.stringify(arguments[i]));
                }
            }
        }

        this.warn = function () {
            if (this.debuggingEnabled) {
                for (var i = 1; i < arguments.length; i++) {
                    $log.warn("[" + $filter('date')(new Date(), this.format) + "] -- " + arguments[0] + " -- " + JSON.stringify(arguments[i]));
                }
            }
        }

        this.error = function () {
            if (this.debuggingEnabled) {
                for (var i = 1; i < arguments.length; i++) {
                    $log.error("[" + $filter('date')(new Date(), this.format) + "] -- " + arguments[0] + " -- " + JSON.stringify(arguments[i]));
                }
            }
        }
   }
]);
