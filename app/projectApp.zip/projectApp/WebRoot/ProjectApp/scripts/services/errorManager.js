angular.module("projectApp.services", [])

.factory("projectApp.services.ErrorsFactory", [

  function () {
        return {

            // Error codes for personal details section of step2

            ER_UC1_1: "Please enter campaign name.",
            ER_UC1_2: "Please enter promo code.",
            ER_UC1_3: "Please enter bonus rate code.",
            ER_UC1_4a: "Please select minimum and maximum amount.",
            ER_UC1_4b: "Minimum amount should be less than the maximum amount.",
            ER_UC1_5: "Please select customer type.",
            ER_UC1_6: "Please select product type.",
            ER_UC1_7: "Please select account type.",
            ER_UC1_8a: "Please enter start and end date.",
            ER_UC1_8b: "Please enter valid start and end date.",
            ER_UC1_8c: "Start and End date should be a future date.",
            ER_UC1_9: "Please enter campain tenure in months.",
            ER_UC1_9b: "Please enter months between 1-60.",
            ER_UC1_10: "Please enter bonus rate.",
            ER_UC1_10b: "Bonus rate should be more than 0.",
            ER_UC1_10c: "Please enter bonus rate upto two decimal places only.",


        };
  }
])

.service("projectApp.services.ErrorManager", ["projectApp.services.ErrorsFactory", function (errorFactory) {
        this.getErrorMessage = function (errCode) {
            return errorFactory[errCode];
        };
  }])
