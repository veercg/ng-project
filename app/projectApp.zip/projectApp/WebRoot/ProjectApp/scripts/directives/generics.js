(function(){
  'use strict';
  angular.module('projectApp').directive('prequalifier', ['$compile', function ($compile) {
      return function (scope, element, attrs) {
          scope.$watch(
              function (scope) {
                  return scope.$eval(attrs.prequalifier);
              },
              function (value) {
                  element.html(value);
                  $compile(element.contents())(scope);
              }
          );
      };
  }]);
})();
