(function () {
    angular.module('projectApp')
        .directive('numbersOnly', numbersOnlyFunc);

    numbersOnlyFunc.$inject = ['$rootScope'];

    function numbersOnlyFunc($rootScope) {
        var directive = {
            replace: true,
            restrict: 'A',
            require: 'ngModel',
            /* template: '<input type="text" placeholder="e.g. +1 702 123 4567">',*/
            link: link
        };

        return directive;

        function link(scope, element, attrs, ngModel) {
            var read = function () {
                /*var inputValue = element.val();*/
                ngModel.$parsers.push(function (inputValue) {
                    // this next if is necessary for when using ng-required on your input.
                    // In such cases, when a letter is typed first, this parser will be called
                    // again, and the 2nd time, the value will be undefined
                    if (inputValue == undefined){
                      return '';
                    }
                    var transformedInput = inputValue.replace(/[^0-9]/g, '');
                    if (transformedInput != inputValue) {
                        ngModel.$setViewValue(transformedInput);
                        ngModel.$render();
                    }

                    return transformedInput;
                });

            };
            element.on('focus blur keyup change', function () {
                scope.$apply(read);
            });
            read();
        }
    }
})();
