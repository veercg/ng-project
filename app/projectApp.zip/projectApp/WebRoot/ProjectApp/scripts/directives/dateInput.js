(function () {
    'use strict';
    angular.module('projectApp')
        .directive('customDateInput', customDateInputFunc);

    customDateInputFunc.$inject = ['$filter'];

    function customDateInputFunc($filter) {
        return {
            restrict: 'A',
            require: '?ngModel',
            scope: {
                yearsintopast: '=',
                yearsintofuture: '='
            },
            templateUrl: 'views/partials/dateInput.html',

            link: function ($scope, $element, $attrs, ngModel) {

                if (!ngModel){
                  return;
                }

                //Set current year in scope
                var currentDate = new Date();
                $scope.maxYear = currentDate.getFullYear() + $scope.yearsintofuture;
                $scope.minYear = currentDate.getFullYear() - $scope.yearsintopast;

                $scope.maxDate = new Date();
                $scope.maxDate.setFullYear($scope.maxYear);

                $scope.minDate = new Date();
                $scope.minDate.setFullYear($scope.minYear);

                //Check for html5 date support
                var i = document.createElement("input");
                i.setAttribute("type", "date");
                $scope.html5DateSupport = (i.type !== "text");

                // when model change, update our view
                ngModel.$render = function () {

                    // update the local view
                    if (ngModel.$modelValue && ngModel.$modelValue.match(/([0-9]{2}\/[0-9]{2}\/[0-9]{4})/g)) {
                        var arr = ngModel.$modelValue.split('/');

                        var day = arr[0];
                        var month = arr[1];
                        var year = arr[2];

                        $scope.dateDay = day;
                        $scope.dateMonth = month;
                        $scope.dateYear = year;

                        // if ($scope.html5DateSupport) {
                            //Fix for iphone
                            var dateStr = (year + '-' + month + '-' + day);
                            $scope.dateInput = new Date(dateStr);
                        // } else {
                        //     $scope.dateInput = (day + '/' + month + '/' + year);
                        // }
                    }
                };

                // update the value when one of the dropdown is changed
                function updateDateSelect(dateDay, dateMonth, dateYear) {

                    // Update the model then the view
                    if ($scope.dateDay && $scope.dateMonth && $scope.dateYear) {
                        ngModel.$viewValue = $scope.dateDay + '/' + $scope.dateMonth + '/' + $scope.dateYear;


                    } else {
                        ngModel.$viewValue = '';
                    }

                    // Update $modelValue
                    ngModel.$setViewValue(ngModel.$viewValue);

                    // Update the local view
                    ngModel.$render();

                    // Validate
                    validate(ngModel.$modelValue);
                }

                // update the value when input value is changed
                function updateDateInput(dateInput) {

                    // Update the model then the view
                    // if (!$scope.html5DateSupport) {
                    //     ngModel.$viewValue = $scope.dateInput;
                    // } else {

                        if ($scope.dateInput != null && typeof $scope.dateInput != 'undefined') {
                            var dob = $scope.dateInput;
                            var dd = dob.getDate();
                            var mm = dob.getMonth() + 1; //January is 0!
                            var yyyy = dob.getFullYear();
                            if (dd < 10) {
                                dd = '0' + dd
                            }
                            if (mm < 10) {
                                mm = '0' + mm
                            }
                            ngModel.$viewValue = dd + '/' + mm + '/' + yyyy;
                        } else {
                            ngModel.$viewValue = $scope.dateInput;
                        }
                    // }

                    // Update $modelValue
                    ngModel.$setViewValue(ngModel.$viewValue);

                    // Update the local view
                    ngModel.$render();

                    // Validate
                    validate(ngModel.$modelValue);
                }


                function isValidDate() {
                    var parts = ngModel.$viewValue.split('/');
                    if (parts.length < 3)
                        return false;
                    else {
                        var day = parseInt(parts[0],10);
                        var month = parseInt(parts[1],10);
                        var year = parseInt(parts[2],10);
                        if (isNaN(day) || isNaN(month) || isNaN(year)) {
                            return false;
                        }

                        if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30)
                            return false;
                        if (month == 2) {
                            if (((year % 4) == 0 && (year % 100) != 0) || ((year % 400) == 0 && (year % 100) == 0)) {
                                if (day > 29)
                                    return false;
                            } else {
                                if (day > 28)
                                    return false;
                            }
                        }
                        return true;
                    }
                }


                //Validator
                function validate(value) {

                    if (!$attrs.required) {
                        return;
                    }

                    //Reset validity state
                    ngModel.$setValidity('required', true);
                    ngModel.$setValidity('pattern', true);
                    ngModel.$setValidity('rangemin', true);
                    ngModel.$setValidity('rangemax', true);
                    ngModel.$setValidity('invaliddate', true);

                    //Check required
                    if (!value) {
                        ngModel.$setValidity('required', false);
                        return;
                    }

                    //Check pattern [dd/mm/yyyy]
                    if (!value.match(/^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[012])\/((19|20)\d\d)$/gi)) {
                        ngModel.$setValidity('pattern', false);
                        return;
                    }

                    //Check invalid date
                    if (!isValidDate()) {
                        ngModel.$setValidity('invaliddate', false);
                        return;
                    }

                    //Check range
                    var arr = ngModel.$modelValue.split('/');
                    var dateValue = new Date(arr[2], arr[1] - 1, arr[0]);

                    //Check greater than minimum date
                    if (dateValue.getTime() < $scope.minDate.getTime()) {
                        ngModel.$setValidity('rangemin', false);
                        return;
                    }

                    //Check less than maximum date
                    if (dateValue.getTime() > $scope.maxDate.getTime()) {
                        ngModel.$setValidity('rangemax', false);
                        return;
                    }

                }

                //
                // Listen for change events to enable binding
                $scope.$watch('dateDay + dateMonth + dateYear', function (newVal, oldVal) {

                    if (newVal < oldVal || newVal > oldVal) {
                        updateDateSelect($scope.dateDay, $scope.dateMonth, $scope.dateYear);
                    }
                });

                // $scope.$watch('dateInput', function(newVal, oldVal) {
                //    //console.log('in date input watch:[' +newVal + "] Old value ["+ oldVal + "]" );
                //
                // 	//console.log($scope.dateInput);
                //    if (oldVal == undefined || newVal < oldVal || newVal > oldVal) {
                //       //console.log('in date input watch - newVal and oldVal are different');
                //       updateDateInput($scope.dateInput);
                //    }
                // });

                // Watch required attribute
                $attrs.$observe('required', function (value) {
                    //Reset validity state
                    if (!value) {
                        ngModel.$setValidity('required', true);
                        ngModel.$setValidity('pattern', true);
                        ngModel.$setValidity('rangemin', true);
                        ngModel.$setValidity('rangemax', true);
                    } else {
                        validate(ngModel.$modelValue);
                    }
                });

                $scope.dateDayVisited = function () {
                    $scope.hasDateDayVisited = true;
                };

                $scope.dateMonthVisited = function () {
                    $scope.hasDateMonthVisited = true;
                };

                $scope.dateYearVisited = function () {
                    $scope.hasDateYearVisited = true;
                };

                $scope.dateInputVisited = function () {
                    $scope.hasDateInputVisited = true;
                    updateDateInput($scope.dateInput);
                };

                $scope.$watch('hasDateDayVisited + hasDateMonthVisited + hasDateYearVisited + hasDateInputVisited', function (newVal, oldVal) {
                    //set hasvisited to true
                    if (($scope.hasDateDayVisited && $scope.hasDateMonthVisited && $scope.hasDateYearVisited) || $scope.hasDateInputVisited) {
                        ngModel.hasVisited = true;
                    }
                });

            }
        };
    }

})();
