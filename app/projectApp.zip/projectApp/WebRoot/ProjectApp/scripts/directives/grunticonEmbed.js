angular.module('projectApp').directive('grunticonEmbed', function () {
    return {
        restrict: 'A',
        scope: false,
        link: function ($scope, $element, $attr) {

            var backgroundSvg = decodeURIComponent(
                $element.css('background-image').slice(4, -1).replace(/"/g, "")
            ).split(',');

            // Only replace when decoded data is of type image/svg+xml
            if (backgroundSvg[0].indexOf("image/svg+xml") > -1) {
                $element.html(backgroundSvg[1]);
                $element.css("background-image", "none");
            }
        }
    };
});
