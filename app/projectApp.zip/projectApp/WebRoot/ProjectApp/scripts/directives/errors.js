! function () {
    'use strict';
    var errors = angular.module('projectApp.errors', []);
    errors.directive('errorContainer', ['$compile',
	      function ($compile) {
            return {
                restrict: "A",
                replace: true,
                transclude: true,
                scope: {
                    field: '='
                },
                template: '<div data-ng-class="{\'has-error\': field.$invalid && field.$dirty, \'has-success\': field.$valid && field.$dirty }">' +
                    '<p class="col-sm-12 col-xs-12 remove-side-padding clearfix" data-ng-show="(field.$invalid && field.$dirty)">' +
                    '<span class="icon icon-size-sm icon-alert"></span>' +
                    '<span ng-show="field.$error.server">{{field.$error.serverText}}</span>' +
                    '<span data-ng-transclude="true" ng-hide="field.$error.server"></span>' +
                    '</p>' +
                    '</div>'
            };
	    }]);
    errors.directive('formField', ['$compile',
	      function ($compile) {
            return {
                restrict: "A",
                replace: true,
                transclude: true,
                scope: {
                    field: '='
                },
                template: '<div data-ng-transclude="true" data-ng-class="{\'alert-form has-danger no-bottom-margin-xs\': field.$invalid && (field.$dirty || $root.isSubmitted), \'has-success\': field.$valid && field.$viewValue }" class="{{ field.$valid && field.$viewValue | iif }}"></div>'
            }
	}]);
}();
