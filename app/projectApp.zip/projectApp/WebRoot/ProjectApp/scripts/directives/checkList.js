(function() {
  'use strict';

  angular
    .module('projectApp')
    .directive('checkList', checkListFunc);

  /* @ngInject */
  function checkListFunc() {
    var directive = {
      restrict: 'A',
      scope: {
        list: '=checkList',
        value: '@'
      },
      link: linkFunc
    };

    return directive;

    function linkFunc(scope, el, attr, ctrl) {
      var handler = function(setup) {
        var checked = el.prop('checked');
        var index = scope.list.indexOf(scope.value);

        if (checked && index == -1) {
          if (setup){
            el.prop('checked', false);
          }
          else{
            scope.list.push(scope.value);
          }
        } else if (!checked && index != -1) {
          if (setup){
            el.prop('checked', true);
          }
          else {
            scope.list.splice(index, 1);
          }
        }
      };

      var setupHandler = handler.bind(null, true);
      var changeHandler = handler.bind(null, false);

      el.on('change', function() {
        scope.$apply(changeHandler);
      });
      scope.$watch('list', setupHandler, true);
    }
  }
})();
