(function () {
    'use strict';

    angular
        .module('projectApp')
        .factory('appFlowFactory', appFlowFactory);

    appFlowFactory.$inject = ['Configuration', '$state', '$rootScope', '$document', '$timeout', 'campaignDataFactory'];

    /* @ngInject */
    function appFlowFactory(Configuration, $state, $rootScope, $document, $timeout, campaignDataFactory) {

        var service = {
            getCurrentStateNum: getCurrentStateNum,
            setCurrentStateNum: setCurrentStateNum,
            validateForm: validateForm,
            moveToState: moveToState
        };

        return service;

        //Details
        function getCurrentStateNum() {
            return $rootScope.stateNum;
        }

        function setCurrentStateNum(newStateNum) {
            $rootScope.stateNum = newStateNum;
        }


        function validateForm() {
            $rootScope.isSubmitted = true;
            var forms = $document.find('form');
            //console.log(angular.element(forms[0]).hasClass('ng-invalid'));
            for (var i = 0; i < forms.length; i++) {
                if (angular.element(forms[i]).hasClass('ng-invalid')) {
                    $timeout(function () {
                        angular.element(forms[i]).find('.ng-invalid:visible:first').focus();
                    });
                    return false;
                }
            }
            return true;

        }
        function moveToState(newStateNum) {
            //console.log("Prev State : " + getCurrentStateNum());
            if (newStateNum >= 0 && newStateNum < Configuration.states.length) {
                $state.go(Configuration.states[newStateNum].name);
                setCurrentStateNum(newStateNum);
                $rootScope.isSubmitted = false;
                console.log("moveToState " + getCurrentStateNum() + " : Success.");
            } else {
                console.log("move To State " + newStateNum + " : Failed.");
            }

            //console.log("Next State : " + getCurrentStateNum());
        }

    }
})();
