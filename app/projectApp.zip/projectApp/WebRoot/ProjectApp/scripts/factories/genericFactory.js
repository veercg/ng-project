(function () {
    'use strict';
    angular.module('projectApp')
        .factory('genericFactory', genericFunctions);
    genericFunctions.$inject = ['$location'];

    function genericFunctions($location) {
        var genericFunction = {};

        //   Used to check if the environment is local or not

        genericFunction.isLocal = function () {
            var isLocal = false;
            var regex_local = /(?:10\.27\.65\.185|127\.0\.0\.1|localhost)/;
            //    var regex_local = /(?:10\.27\.66\.227|127\.0\.0\.1|localhost)/;
            if (regex_local.test($location.host())) {
                isLocal = true;
            }
            return isLocal;
        };

        genericFunction.isDevLocal = function () {
            var isLocal = false;
            var regex_local = /(?:localhost|127\.0\.0\.1)/;
            //    var regex_local = /(?:10\.27\.66\.227|127\.0\.0\.1|localhost)/;
            if (regex_local.test($location.host())) {
                isLocal = true;
            }
            return isLocal;
        };

        genericFunction.getUnformattedCurrency = function (amount) {
            if (angular.isUndefined(amount)){
              return;
            }
            if (amount.indexOf(',') != -1) {
                amount = amount.split(",").join("");
            }
            return amount;
        };
        // converts dd/mm/yyyy or yyyy-mm-dd to dd mmm yyyy
        genericFunction.formatDate = function (inputDate) {
            var monthsName = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            if (angular.isUndefined(inputDate)) {
              return;
            }
            if (inputDate.indexOf('/') != -1) {
                var arrdateParts = inputDate.split("/");
                var dobMonth = arrdateParts[1] - 1;
                return arrdateParts[0] + ' ' + monthsName[dobMonth] + ' ' + arrdateParts[2];
            } else if (inputDate.indexOf('-') != -1) {
                var arrdateParts = inputDate.split("-");
                var dobMonth = arrdateParts[1] - 1;
                return arrdateParts[2] + ' ' + monthsName[dobMonth] + ' ' + arrdateParts[0];
            } else {
                return '';
            }
        }

        genericFunction.formatCurrencyWithFloor = function (amount) {
            if (!isNaN(amount)) {
                amount = Math.floor(amount);
                amount = amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            } else {
                amount = "";
            }
            return amount;
        }

        genericFunction.getOrigin = function (url) {
            var arr = (url + "").split("//");
            var origin = arr[0] + "//" + arr[1].substring(0, arr[1].indexOf("/"));
            return origin;
        }

        genericFunction.openUrlNewTab = function (url) {
          window.open(url,'_blank');
        }

        genericFunction.decimalPlaces = function (num) {
          var match = (''+num).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
          if (!match) { return 0; }
          return Math.max(
               0,
               // Number of digits right of decimal point.
               (match[1] ? match[1].length : 0)
               // Adjust for scientific notation.
               - (match[2] ? +match[2] : 0));
        }
        return genericFunction;
    }
})();
