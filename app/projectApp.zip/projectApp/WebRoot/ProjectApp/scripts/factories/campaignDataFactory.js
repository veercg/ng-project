(function () {
    'use strict';

    angular.module('projectApp')
        .factory('campaignDataFactory', function () {
            // Detailed Descriptions

            var campaignDetails = {
                cName: undefined,
                cDescription: undefined,
                cPromoCode: undefined,
                cBonusRateCode: undefined,
                cMinAmount: undefined,
                cMaxAmount: undefined,
                cCustomerType: undefined,
                cProductType: undefined,
                cAccountType: undefined,
                cStartDate: undefined,
                cEndDate: undefined,
                cTenure: undefined,
                cInterestFrequency: undefined,
                cBonusRate: undefined,
                cComments: undefined
            };

            var clearFactoryData = function () {

                this.campaignDetails = {
                  cName: undefined,
                  cDescription: undefined,
                  cPromoCode: undefined,
                  cBonusRateCode: undefined,
                  cMinAmount: undefined,
                  cMaxAmount: undefined,
                  cCustomerType: undefined,
                  cProductType: undefined,
                  cAccountType: undefined,
                  cStartDate: undefined,
                  cEndDate: undefined,
                  cTenure: undefined,
                  cInterestFrequency: undefined,
                  cBonusRate: undefined,
                  cComments: undefined
                };

            }
            var service = {
                campaignDetails: campaignDetails,
                clearFactoryData: clearFactoryData
            };
            return service;

        });

})();
