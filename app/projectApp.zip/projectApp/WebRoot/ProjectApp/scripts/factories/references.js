! function() {
  'use strict';
    angular.module('projectApp')
        .factory('referenceData', referenceDataFunc);
    referenceDataFunc.$inject = [];
    function referenceDataFunc() {

      return {
        envProperties : undefined,
        campaignAmountList: ['5000','10000','20000','50000','100000','250000','500000','1000000','2000000','5000000','10000000','25000000'],
        campaignTenureRange: {
          minValue: 1,
          maxValue: 60
        },
        empStatusList: [{
          id: 'FT',
          value: 'Full Time'
        }, {
          id: 'PT',
          value: 'Part Time'
        }, {
          id: 'DC',
          value: 'Dependent Contractor'
        }, {
          id: 'IC',
          value: 'Independent Contractor'
        }, {
          id: 'SE',
          value: 'Self Employed'
        }, {
          id: 'CA',
          value: 'Casual'
        }, {
          id: 'TE',
          value: 'Temporary'
        }, {
          id: 'UN',
          value: 'Unemployed'
        }, {
          id: 'SS',
          value: 'Social Security Recipient'
        }, {
          id: 'RE',
          value: 'Retired'
        }, {
          id: 'ST',
          value: 'Student'
        }, {
          id: 'OT',
          value: 'Other (Home Duties/Work Compensation)'
        }],
        //values for Altitude Business Step 3 Business and Employment Page

        states: [{
          id: 'ACT',
          name: 'Australian Capital Territory (ACT)'
        }, {
          id: 'NSW',
          name: 'New South Wales (NSW)'
        }, {
          id: 'NT',
          name: 'Northern Territory (NT)'
        }, {
          id: 'QLD',
          name: 'Queensland (QLD)'
        }, {
          id: 'SA',
          name: 'South Australia (SA)'
        }, {
          id: 'TAS',
          name: 'Tasmania (TAS)'
        }, {
          id: 'VIC',
          name: 'Victoria (VIC)'
        }, {
          id: 'WA',
          name: 'Western Australia (WA)'
        }],

        POWords: [{
            value: 'BOX[0-9]'
          }, {
            value: 'C/-PO[0-9]+'
          }, {
            value: 'C/PO[0-9]+'
          }, {
            value: 'CAREOFPOSTOFFICE'
          }, {
            value: 'CAREPO'
          }, {
            value: 'CMA[0-9]+'
          }, {
            value: 'CMB[0-9]+'
          }, {
            value: 'CPA[0-9]+'
          }, {
            value: 'GENERALPOSTOFFICE'
          }, {
            value: 'GPOBOX'
          }, {
            value: 'GPOFFICE[0-9]+'
          }, {
            value: 'GPOSTOFFICE[0-9]+'
          }, {
            value: 'LOCKBAG'
          }, {
            value: 'LOCKBOX'
          }, {
            value: 'LOCKEDBAG'
          }, {
            value: 'LOCKEDBOX'
          }, {
            value: 'MAILBAG'
          }, {
            value: 'MS[0-9]+'
          }, {
            value: 'P0B0X'
          }, {
            value: 'PO[0-9]+'
          }, {
            value: 'POB[0-9]+'
          }, {
            value: 'POBOX'
          }, {
            value: 'POFFICEBOX'
          }, {
            value: 'POSTERESTANTE'
          }, {
            value: 'POSTOFFICEBOX'
          }, {
            value: 'PRIVATEBAG'
          }, {
            value: 'PRIVBAG'
          }, {
            value: 'RMB[0-9]+'
          }, {
            value: 'RMBO[0-9]+'
          }, {
            value: 'RMS[0-9]+'
          }, {
            value: 'ROYALMAILBOX'
          }, {
            value: 'RSD[0-9]+'
          }

        ],

        titles: [{
          id: 'Mr',
          value: 'Mr'
        }, {
          id: 'Mrs',
          value: 'Mrs'
        }, {
          id: 'Ms',
          value: 'Ms'
        }, {
          id: 'Miss',
          value: 'Miss'
        }, {
          id: 'Dr',
          value: 'Dr'
        }, {
          id: 'Prof',
          value: 'Professor'
        }, {
          id: 'Rev',
          value: 'Reverend'
        }, {
          id: 'Sis',
          value: 'Sister'
        }, {
          id: 'Fr',
          value: 'Father'
        }, {
          id: 'Past',
          value: 'Pastor'
        }, {
          id: 'Br',
          value: 'Brother'
        }, {
          id: 'Lady',
          value: 'Lady'
        }, {
          id: 'Mada',
          value: 'Madam'
        }, {
          id: 'Madm',
          value: 'Madame'
        }, {
          id: 'Cpt',
          value: 'Captain'
        }, {
          id: 'Majo',
          value: 'Major'
        }, {
          id: 'Col',
          value: 'Colonel'
        }, {
          id: 'Lt',
          value: 'Lieutenant'
        }],
        day: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18,
          19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31
        ],
        months: [{
          id: '01',
          value: 'Jan'
        }, {
          id: '02',
          value: 'Feb'
        }, {
          id: '03',
          value: 'Mar'
        }, {
          id: '04',
          value: 'Apr'
        }, {
          id: '05',
          value: 'May'
        }, {
          id: '06',
          value: 'Jun'
        }, {
          id: '07',
          value: 'Jul'
        }, {
          id: '08',
          value: 'Aug'
        }, {
          id: '09',
          value: 'Sept'
        }, {
          id: '10',
          value: 'Oct'
        }, {
          id: '11',
          value: 'Nov'
        }, {
          id: '12',
          value: 'Dec'
        }],
        monthsFullName: [{
          id: '01',
          value: 'January'
        }, {
          id: '02',
          value: 'February '
        }, {
          id: '03',
          value: 'March'
        }, {
          id: '04',
          value: 'April'
        }, {
          id: '05',
          value: 'May'
        }, {
          id: '06',
          value: 'June'
        }, {
          id: '07',
          value: 'July'
        }, {
          id: '08',
          value: 'August'
        }, {
          id: '09',
          value: 'September'
        }, {
          id: '10',
          value: 'October'
        }, {
          id: '11',
          value: 'November'
        }, {
          id: '12',
          value: 'December'
        }]

      }
    }

}();
