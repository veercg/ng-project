(function () {
    'use strict';

    angular
        .module('projectApp')
        .controller('campaignCtrl', campaignCtrlFunc);

    campaignCtrlFunc.$inject = ['$scope'];

    /* @ngInject */
    function campaignCtrlFunc($scope) {

    }

})();
