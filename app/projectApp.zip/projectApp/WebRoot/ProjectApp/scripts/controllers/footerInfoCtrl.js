! function () {
    'use strict';

    angular.module('projectApp')
        .controller('footerInfoCtrl', footerInfoCtrlFunc);

    footerInfoCtrlFunc.$inject = ['$scope', '$location', 'referenceData','genericFactory'];

    function footerInfoCtrlFunc($scope, $location, referenceData, genericFactory) {
        console.log("FOOTER INFO CONTROLLER INVOKED");

        // Environment properties data
        $scope.envProperties = referenceData.envProperties;
        $scope.openUrlNewTab = genericFactory.openUrlNewTab;
    }
}();
