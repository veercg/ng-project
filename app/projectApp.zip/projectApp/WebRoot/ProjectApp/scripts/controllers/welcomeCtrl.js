(function() {
  'use strict';

  angular.module('projectApp')
    .controller('welcomeCtrl', welcomeCtrlFunc);

  welcomeCtrlFunc.$inject = ['$scope','$rootScope', 'Configuration', 'appFlowFactory'];

  function welcomeCtrlFunc($scope, $rootScope, Configuration, appFlowFactory) {
    console.log("Welcome Controller Invoked.");

    // To check if the environment is local or not
    $scope.isLocal = genericFactory.isLocal();
    appFlowFactory.setCurrentStateNum(0);


    var init = function() {

    }
    init();


  }
})();
