(function () {
    'use strict';

    angular.module('projectApp')
        .controller('errorCtrl', errorCtrlFunc);

    errorCtrlFunc.$inject = ['$scope', '$location', '$rootScope', 'Configuration', 'campaignDataFactory', 'referenceData', 'appFlowFactory', '$timeout'];

    function errorCtrlFunc($scope, $location, $rootScope, Configuration, campaignDataFactory, referenceData, appFlowFactory, $timeout) {
        console.log("ERROR CONTROLLER INVOKED");

        // For Step
        appFlowFactory.setCurrentStateNum(8);

        // To open the top of the page when this page opens
        $(document).ready(function () {
            $(this).scrollTop(0);
        });

        $scope.goToWestpacHomePage = function () {
            window.location.href = referenceData.envProperties.westpacHomePage;
        }

        
    }
})();
