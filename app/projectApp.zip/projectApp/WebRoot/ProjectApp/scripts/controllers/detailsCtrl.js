(function () {
    'use strict';

    angular
        .module('projectApp')
        .controller('detailsCtrl', detailsCtrlFunc);

    detailsCtrlFunc.$inject = ['$scope'];

    /* @ngInject */
    function detailsCtrlFunc($scope) {


    }

})();
