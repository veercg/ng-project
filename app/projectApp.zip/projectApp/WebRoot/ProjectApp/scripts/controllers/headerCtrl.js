(function() {
  'use strict';

  angular
    .module('projectApp')
    .controller('headerCtrl', headerCtrlFunc);

  headerCtrlFunc.$inject = ['$scope'];

  /* @ngInject */
  function headerCtrlFunc($scope) {

  }
})();
