(function() {
    'use strict';

    angular
        .module('projectApp')
        .controller('createCtrl', createCtrlFunc);

    createCtrlFunc.$inject = ['$scope','$rootScope', 'appFlowFactory', 'campaignDataFactory', 'referenceData','genericFactory'];

    /* @ngInject */
    function createCtrlFunc($scope, $rootScope, appFlowFactory, campaignDataFactory, referenceData, genericFactory) {

        // Storing Campaign Details data
        $scope.campaignDetails = campaignDataFactory.campaignDetails;

        // Fill data
        $scope.campaignDetails.cBonusRateCode = "HOTL";
        $scope.campaignDetails.cInterestFrequency = "Yearly";

        $scope.numberWithCommas = function(x) {
            return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        $scope.cAmountList = referenceData.campaignAmountList;
        $scope.cCustomerTypeList = referenceData.customerTypeList;
        $scope.cProductTypeList = referenceData.productTypeList;
        $scope.cAccountTypeList = referenceData.accountTypeList;

        // Validations
        // 1. For Campaign Minimum and Maximum amount
        $scope.cAmountInvalid = false;
        var validateCAmount = function() {
            if(!angular.isUndefined($scope.campaignDetails.cMinAmount) && !angular.isUndefined($scope.campaignDetails.cMaxAmount) && $scope.campaignDetails.cMinAmount.length > 0 && $scope.campaignDetails.cMaxAmount.length > 0){
              $scope.cAmountInvalid = false;
              $scope.formCreateCamp.cMinAmount.$setValidity('parse', true);
              $scope.formCreateCamp.cMaxAmount.$setValidity('parse', true);

              if(parseInt($scope.campaignDetails.cMinAmount,10) >= parseInt($scope.campaignDetails.cMaxAmount,10)){
                $scope.cAmountInvalid = true;
                $scope.formCreateCamp.cMinAmount.$setValidity('parse', false);
                $scope.formCreateCamp.cMaxAmount.$setValidity('parse', false);
              }
              else{
                $scope.cAmountInvalid = false;
                $scope.formCreateCamp.cMinAmount.$setValidity('parse', true);
                $scope.formCreateCamp.cMaxAmount.$setValidity('parse', true);
              }
            }
        }
        $scope.$watch('campaignDetails.cMinAmount + campaignDetails.cMaxAmount', function(newVal, oldVal) {
            validateCAmount();
        });

        // 2. For tenure
        $scope.minTenureValue = referenceData.campaignTenureRange.minValue;
        $scope.maxTenureValue = referenceData.campaignTenureRange.maxValue;

        //3. For Bonus rate
        $scope.cBonusRateMinInvalid = false;
        $scope.cBonusRateDecimalInvalid = false;
        var validateBonusRate = function(){
          if(!angular.isUndefined($scope.campaignDetails.cBonusRate)){
            $scope.cBonusRateMinInvalid = false;
            $scope.cBonusRateDecimalInvalid = false;

            if(genericFactory.decimalPlaces($scope.campaignDetails.cBonusRate)>2){
              $scope.cBonusRateDecimalInvalid = true;
              $scope.formCreateCamp.cBonusRate.$setValidity('parse', false);
            }
            else{
              $scope.cBonusRateDecimalInvalid = false;
              $scope.formCreateCamp.cBonusRate.$setValidity('parse', true);
            }

            if(!$scope.cBonusRateDecimalInvalid){
              if(parseFloat($scope.campaignDetails.cBonusRate)<=0){
                $scope.cBonusRateMinInvalid = true;
                $scope.formCreateCamp.cBonusRate.$setValidity('parse', false);
              }
              else{
                $scope.cBonusRateMinInvalid = false;
                $scope.formCreateCamp.cBonusRate.$setValidity('parse', true);
              }
            }
          }
        }
        $scope.$watch('campaignDetails.cBonusRate', function(newVal, oldVal) {
            validateBonusRate();
        });

        //4. For Start End Date
        $scope.cStartEndPastInvalid = false;
        var validateStartEndDate = function(){
          if(!angular.isUndefined($scope.campaignDetails.cStartDate) && !angular.isUndefined($scope.campaignDetails.cEndDate)){
            var cStartDate = new Date($scope.campaignDetails.cStartDate);
            var cEndDate = new Date($scope.campaignDetails.cEndDate);
            var todaysDate = new Date();
            cStartDate = cStartDate.setHours(0,0,0,0);
            cEndDate = cEndDate.setHours(0,0,0,0);
            todaysDate = todaysDate.setHours(0,0,0,0);

            console.log(cStartDate);
            console.log(cEndDate);
            console.log(todaysDate);

            if(cStartDate <= todaysDate || cEndDate <= todaysDate){
              $scope.cStartEndPastInvalid = true;
              $scope.formCreateCamp.cStartDate.$setValidity('parse', false);
              $scope.formCreateCamp.cEndDate.$setValidity('parse', false);
            }
            else{
              $scope.cStartEndPastInvalid = false;
              $scope.formCreateCamp.cStartDate.$setValidity('parse', true);
              $scope.formCreateCamp.cEndDate.$setValidity('parse', true);
            }
          }
        }
        $scope.$watch('campaignDetails.cStartDate + campaignDetails.cEndDate', function(newVal, oldVal) {
            validateStartEndDate();
        });
        // On Submit of form
        $scope.submitForm = function() {
            if(appFlowFactory.validateForm()){
              console.log($scope.campaignDetails);
            }
        }
            // Navigating to states
        $scope.cancelForm = function() {
            campaignDataFactory.clearFactoryData();
            appFlowFactory.moveToState(0);
        }

    }

})();
