(function() {
  'use strict';

  angular.module('projectApp')
    .controller('summaryCtrl', summaryCtrlFunc);

  summaryCtrlFunc.$inject = ['$scope','$rootScope', 'Configuration', 'appFlowFactory'];

  function summaryCtrlFunc($scope, $rootScope, Configuration, appFlowFactory) {
    console.log("Summary Controller Invoked.");

    
    var init = function() {

    }
    init();


  }
})();
