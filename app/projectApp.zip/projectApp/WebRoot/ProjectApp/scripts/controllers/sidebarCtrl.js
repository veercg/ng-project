(function() {
    'use strict';

    angular
        .module('projectApp')
        .controller('sidebarCtrl', sidebarCtrlFunc);

    sidebarCtrlFunc.$inject = ['$scope','$state','appFlowFactory'];

    /* @ngInject */
    function sidebarCtrlFunc($scope,$state,appFlowFactory) {

      $scope.selectedTab = appFlowFactory.getCurrentStateNum();

      $scope.goToState = function(stateNum){
        appFlowFactory.moveToState(stateNum);
        $scope.selectedTab = appFlowFactory.getCurrentStateNum();
      }
    }
})();
