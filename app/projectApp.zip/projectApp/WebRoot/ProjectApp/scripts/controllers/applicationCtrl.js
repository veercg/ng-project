(function() {
  'use strict';

  angular.module('projectApp')
    .controller('applicationCtrl', applicationCtrlFunc);

  applicationCtrlFunc.$inject = ['$scope', '$rootScope', 'projectApp.services.ErrorManager', 'Configuration', '$state', '$location', 'appFlowFactory', 'campaignDataFactory', 'genericFactory', '$timeout'];

  function applicationCtrlFunc($scope, $rootScope, errorManager, Configuration, $state, $location, appFlowFactory, campaignDataFactory, genericFactory, $timeout) {
    console.log("Application Controller Invoked.");
    //  start - navigation login for the Application

    appFlowFactory.setCurrentStateNum(0);

    //end - navigation login for the Application

    $scope.errorMessage = function(errCode) {
      return errorManager.getErrorMessage(errCode);
    };

    /**
     * All the navigation or state change logic reside here

     */
    $scope.resetApplication = function() {
      campaignDataFactory.clearFactoryData();
      Configuration.resetAllStates();
      $rootScope.isSubmitted = false;
    }
    $scope.$on('$stateChangeStart',
      function(event, toState, toParams, fromState, fromParams) {

        var oldState = $scope.getPosition(Configuration.states, fromState.name);
        var newState = $scope.getPosition(Configuration.states, toState.name);
        /* Mapping
        	Page : StateNum
        	Welcome : 0,
        	Details : 1,
        	Create : 2,
        	Error : 3
        */

        console.log("old: " +oldState);
        console.log("new: " +newState);
        var isDevLocal = genericFactory.isDevLocal();
        var $pageLoading = $(".page-loading");
        if ((angular.isUndefined($rootScope.navigateContinue) || !$rootScope.navigateContinue) && newState > 0 && newState < 7 && !isDevLocal) {
          // If user is  or congrats or decision on Error page.

          if (oldState === 6 || oldState === 7 || oldState === 8) {
            if (oldState != newState) {
              $pageLoading.removeClass("hidden");
            }
            event.preventDefault();
            $scope.resetApplication();
            $state.go('summary');
          }
          // If user presses back button while staying on verify page
          if ((newState < oldState) && oldState === 5) {
            /*if (oldState === 5) {*/
              $rootScope.backBtnPressed = true;
              event.preventDefault();
              return;
            /*}*/
          }
          // If user tries to skip any page in between
          if (newState > oldState) {
            if (oldState !== newState) {
              $pageLoading.removeClass("hidden");
            }
            event.preventDefault();
            $scope.resetApplication();
            $state.go('summary');
          }
        } else {
          $pageLoading.removeClass("hidden");
          if ((oldState === -1) && (newState === 5 || newState === 6 || newState === 7 || newState === 8)) {
              event.preventDefault();
              $scope.resetApplication();
              $state.go('summary');
          }

        }

      });

    $scope.$on('$stateChangeSuccess',
      function(event, toState, toParams, fromState, fromParams) {
        $("#productTitle").html("");
        $("#footerInfo").html("");
        $(".page-loading").addClass("hidden");
        $rootScope.backBtnPressed = false;
        $rootScope.navigateContinue = false;
      });


    /**
     * returns the position of a state in the states array

     * @param {Array} states array
     * @param {Number} state name
     * @return {Number} position of the given state in the states array
     */
    $scope.getPosition = function(array, val) {
      var result = -1;
      for (var i = 0; i < array.length; i++) {
        if (array[i].name === val) {
          result = array[i].stateNum;
          break;
        }
      }
      return result;
    }
  }

})();
