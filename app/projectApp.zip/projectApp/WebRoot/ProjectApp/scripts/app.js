! function() {
  'use strict';

  var projectApp = angular.module('projectApp', ['ui.router', 'ui.bootstrap', 'ngCookies','infinite-scroll', 'main_app.templates.td.common', 'projectApp.errors', 'projectApp.formValidation', 'projectApp.services']);

  projectApp.provider('Configuration', function() {
    this.isMobile = detectMobile();
    this.iPad = false;
    this.isNative = false;
    this.pageNum;
    this.isTablet = detectTablet();
    this.addrChanged = false;
    this.ShowQASAddr = false;
    this.lookUpAddress = 'qas';
    this.shouldCreateCookie = true;
    this.isExplorer = (window.navigator.userAgent).toLowerCase().indexOf("msie") > 0;

    this.isSessionStorageSupported = (function() {
      var testKey = 'test';
      try {
        window.sessionStorage.setItem(testKey, '1');
        window.sessionStorage.removeItem(testKey);
        return true;
      } catch (error) {
        return false;
      }
    })();
    this.states = [{
      "stateNum": 0,
      "name": "summary",
      "valid": false
    },{
      "stateNum": 1,
      "name": "create",
      "valid": false
    },{
      "stateNum": 2,
      "name": "campaign",
      "valid": false
    },{
      "stateNum": 3,
      "name": "error",
      "valid": false
    }];

    this.$get = function() {
      return this;
    };
    this.appMode = function() {
      return this.isMobile ? "mobile" : "desktop";
    };
    this.getOrigChannel = function() {
      return "TD";
    };
    this.resetAllStates = function() {
      angular.forEach(this.states, function(item) {
        item.valid = false;
      });
    }

    function detectMobile() {
      return Modernizr.mq('only screen and (max-width: 480px)');
    }

    function detectTablet() {
      return Modernizr.mq('only screen and (max-width: 768px)');
    }
  });

  projectApp.config(['$stateProvider', '$urlRouterProvider', 'ConfigurationProvider', '$compileProvider',
    function($stateProvider, $urlRouterProvider, Configuration, $compileProvider) {

      // $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|file|tel):/);
      //
      // // For session id generation
      // if (Configuration.shouldCreateCookie) {
      //   var randomNumber = getUniqueId();
      //   if (!isEmptyObject(getCookie('TD_XSRF_TOKEN'))) {
      //     eraseCookie('TD_XSRF_TOKEN');
      //   }
      //   setCookie('TD_XSRF_TOKEN', randomNumber, '', '/');
      //
      //
      //   var currTime = getCurrentTime();
      //   var CORRELATION_ID_VALUE = currTime + " WBC_Everyday Banking_Term Deposit";
      //   if (CORRELATION_ID_VALUE) {
      //     CORRELATION_ID_VALUE = CORRELATION_ID_VALUE.trim();
      //   }
      //   if (!isEmptyObject(getCookie('CORRELATION_ID'))) {
      //     eraseCookie('CORRELATION_ID');
      //   }
      //   setCookie('CORRELATION_ID', CORRELATION_ID_VALUE, '', '/');
      //
      //   Configuration.shouldCreateCookie = false;
      // }

      $urlRouterProvider.when('', '/');
      $urlRouterProvider.otherwise('/');
      $stateProvider
        .state('summary', {
          url: '/',
          name: 'summary',
          views: {
            'sidebar': {
              templateUrl: 'views/partials/sidebar.html',
              controller: 'sidebarCtrl'
            },
            'header': {
              templateUrl: 'views/partials/header.html',
              controller: 'headerCtrl'
            },
            'mainContentWelcome': {
              templateUrl: 'views/summary.html',
              controller: 'summaryCtrl'
            }
          }
        })
        .state('create', {
          url: '/create',
          name: 'create',
          views: {
            'sidebar': {
              templateUrl: 'views/partials/sidebar.html',
              controller: 'sidebarCtrl'
            },
            'header': {
              templateUrl: 'views/partials/header.html',
              controller: 'headerCtrl'
            },
            'mainContentWelcome': {
              templateUrl: 'views/create.html',
              controller: 'createCtrl',
            }
          }
        })
        .state('campaign', {
          url: '/campaign',
          name: 'campaign',
          views: {
            'sidebar': {
              templateUrl: 'views/partials/sidebar.html',
              controller: 'sidebarCtrl'
            },
            'header': {
              templateUrl: 'views/partials/header.html',
              controller: 'headerCtrl'
            },
            'mainContentWelcome': {
              templateUrl: 'views/campaign.html',
              controller: 'campaignCtrl',
            }
          }
        })
        .state('error', {
          url: '/error',
          name: 'error',
          views: {
            'sidebar': {
              templateUrl: 'views/partials/sidebar.html',
              controller: 'sidebarCtrl'
            },
            'header': {
              templateUrl: 'views/partials/header.html',
              controller: 'headerCtrl'
            },
            'mainContentWelcome': {
              templateUrl: 'views/error.html',
              controller: 'errorCtrl'
            }
          }
        })
    }
  ]);
}();
