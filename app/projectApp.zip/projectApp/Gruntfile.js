module.exports = function(grunt) {

    var SOURCE_PATH = 'WebRoot/ProjectApp/';
    var DESTINATION_PATH = 'build/WebRoot/theme/';

    grunt
        .initConfig({
            pkg: grunt.file.readJSON('package.json'),
            copy: {
                prod: {
                    files: [{
                            expand: true,
                            cwd: SOURCE_PATH,
                            src: [
                                'bower_components/**',
                                'fonts/**',
                                'images/**',
                                'gel/assets/css/**',
                                'gel/assets/font/**',
                                'gel/css/**',
                                'res/**'
                            ],
                            dest: DESTINATION_PATH
                        },
                        {
                            expand: true,
                            cwd: SOURCE_PATH,
                            src: ['index.html', 'error.html', 'error404.html'],
                            dest: 'build/WebRoot/ProjectApp/'
                        }
                    ]
                }
            },

            clean: {
                prod: [DESTINATION_PATH]
            },

            cssmin: {
                prod: {
                    expand: true,
                    cwd: SOURCE_PATH + 'css/',
                    src: ['*.css'],
                    dest: DESTINATION_PATH + 'css/'
                }
            },

            concat: {
                options: {
                    separator: ';'
                },
                prod: {
                    cwd: SOURCE_PATH,
                    files: {
                        'build/WebRoot/theme/scripts/libs.js': [
                            SOURCE_PATH + 'scripts/vendor/jquery.min.js',
                            SOURCE_PATH + 'scripts/vendor/jquery.cookie.js',
                            SOURCE_PATH + 'scripts/vendor/isMobile.min.js.js',
                            SOURCE_PATH + 'scripts/vendor/angular.min.js',
                            SOURCE_PATH + 'scripts/vendor/angular-route.min.js',
                            SOURCE_PATH + 'scripts/vendor/angular-ui-router.js',
                            SOURCE_PATH + 'scripts/vendor/angular-ui/ui-bootstrap-tpls-1.1.1.min.js',
                            SOURCE_PATH + 'scripts/vendor/bootstrap.min.js',
                            SOURCE_PATH + 'scripts/vendor/angular-cookies.min.js',
                            SOURCE_PATH + 'scripts/vendor/underscore-min.js',
                            SOURCE_PATH + 'scripts/vendor/modernizr.js',
                            SOURCE_PATH + 'scripts/vendor/ng-infinite-scroll-min.js',
                            SOURCE_PATH + 'scripts/vendor/date-input-polyfill.min.js'
                        ],
                        'build/WebRoot/theme/scripts/application.js': [
                            SOURCE_PATH + 'scripts/app.js',
                            SOURCE_PATH + 'scripts/factories/references.js',
                            SOURCE_PATH + 'scripts/factories/campaignDataFactory.js',
                            SOURCE_PATH + 'scripts/factories/appFlowFactory.js',
                            SOURCE_PATH + 'scripts/factories/genericFactory.js',
                            SOURCE_PATH + 'scripts/services/errorManager.js',
                            SOURCE_PATH + 'scripts/services/genericServices.js',
                            SOURCE_PATH + 'scripts/services/RESTAPIService.js',
                            SOURCE_PATH + 'scripts/services/stepsValidation.js',
                            SOURCE_PATH + 'scripts/directives/errors.js',
                            SOURCE_PATH + 'scripts/directives/numbersOnly.js',
                            SOURCE_PATH + 'scripts/directives/grunticonEmbed.js',
                            SOURCE_PATH + 'scripts/directives/standardAmount.js',
                            SOURCE_PATH + 'scripts/directives/generics.js',
                            SOURCE_PATH + 'scripts/controllers/applicationCtrl.js',
                            SOURCE_PATH + 'scripts/controllers/headerCtrl.js',
                            SOURCE_PATH + 'scripts/controllers/sidebarCtrl.js',
                            SOURCE_PATH + 'scripts/controllers/summaryCtrl.js',
                            SOURCE_PATH + 'scripts/controllers/campaignCtrl.js',
                            SOURCE_PATH + 'scripts/controllers/createCtrl.js',
                            SOURCE_PATH + 'scripts/controllers/footerInfoCtrl.js',
                            SOURCE_PATH + 'scripts/controllers/errorCtrl.js',
                            SOURCE_PATH + 'scripts/filters/genericFilters.js',
                            SOURCE_PATH + 'scripts/common/common.js',
                        ]
                    }
                }
            },
            uglify: {
                options: {
                    compress: {
                        drop_console: true
                    }
                },
                prod: {
                    files: [{
                        expand: true,
                        cwd: DESTINATION_PATH + 'scripts/',
                        src: 'application.js',
                        dest: DESTINATION_PATH + 'scripts/'
                    }]
                }
            },

            ngtemplates: {

                'main_app.templates.td.common': {
                    cwd: SOURCE_PATH,
                    src: ['views/partials/*.html', 'views/*.html'],
                    dest: DESTINATION_PATH + 'scripts/td.common.templates.js',
                    options: {
                        htmlmin: {
                            collapseWhitespace: true,
                            collapseBooleanAttributes: true,
                            removeComments: true
                        }
                    }
                }
            },

            useminPrepare: {
                html: SOURCE_PATH + 'index.html',
                options: {
                    dest: 'build/WebRoot/ProjectApp/',
                    flow: {
                        html: {
                            steps: {
                                css: ['cssmin']
                            },
                            post: {}
                        }
                    }
                }

            },

            filerev: {
                options: {
                    encoding: 'utf8',
                    algorithm: 'md5',
                    length: 20
                },
                release: {
                    files: [{
                        src: [
                            DESTINATION_PATH + 'css/addon.css',
                            DESTINATION_PATH + 'css/desktop.css',
                            DESTINATION_PATH + 'scripts/*.js',
                        ]
                    }]
                }
            },

            usemin: {
                html: ['build/WebRoot/ProjectApp/index.html'],
                options: {
                    assetsDirs: [DESTINATION_PATH]
                }
            },


            dom_munger: {
                prod: {
                    options: {
                        prefix: [{
                            selector: 'link',
                            attribute: 'href',
                            value: '/campaign/oao/theme/'
                        }, {
                            selector: 'script',
                            attribute: 'src',
                            value: '/campaign/oao/theme/'
                        }]
                    },
                    src: 'build/WebRoot/ProjectApp/index.html',
                    dest: 'build/WebRoot/ProjectApp/index.html'
                }
            }

        });

    // grunt.registerTask('default', ['clean', 'copy:prod', 'cssmin:prod', 'concat:prod',
    //     'ngtemplates', 'uglify:prod', 'filerev', 'usemin', 'dom_munger'
    // ]);
    grunt.registerTask('default', ['clean', 'copy:prod', 'cssmin:prod', 'concat:prod',
        'ngtemplates', 'filerev', 'usemin', 'dom_munger'
    ]);


    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-contrib-copy');
    grunt.loadNpmTasks('grunt-devtools');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-angular-templates');
    grunt.loadNpmTasks('grunt-filerev');
    grunt.loadNpmTasks('grunt-usemin');
    grunt.loadNpmTasks('grunt-dom-munger');
};
